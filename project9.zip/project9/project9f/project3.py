'''
Hope Ukolov
House with road and flowers
'''


# loads the Turtle graphics module, which is a built-in library in Python
import turtle
import math

def setup_turtle():
    """Initialize turtle with standard settings"""
    t = turtle.Turtle()
    t.speed(0)  # Fastest speed
    screen = turtle.Screen()
    screen.title("Turtle Graphics Assignment")
    return t, screen


def draw_rectangle(t, width, height, fill_color=None):
    """Draw a rectangle with optional fill"""
    if fill_color:
        t.fillcolor(fill_color)
        t.begin_fill()
    for _ in range(2):
        t.forward(width)
        t.right(90)
        t.forward(height)
        t.right(90)
    if fill_color:
        t.end_fill()

def draw_square(t, size, fill_color=None):
    """Draw a square with optional fill"""
    if fill_color:
        t.fillcolor(fill_color)
        t.begin_fill()
    for _ in range(4):
        t.forward(size)
        t.right(90)
    if fill_color:
        t.end_fill()


def draw_triangle(t, size, fill_color=None):
    """Draw an equilateral triangle with optional fill"""
    if fill_color:
        t.fillcolor(fill_color)
        t.begin_fill()
    for _ in range(3):
        t.forward(size)
        t.left(120)
    if fill_color:
        t.end_fill()


def draw_circle(t, radius, fill_color=None):
    """Draw a circle with optional fill"""
    if fill_color:
        t.fillcolor(fill_color)
        t.begin_fill()
    t.circle(radius)
    if fill_color:
        t.end_fill()


def draw_polygon(t, sides, size, fill_color=None):
    """Draw a regular polygon with given number of sides"""
    if fill_color:
        t.fillcolor(fill_color)
        t.begin_fill()
    angle = 360 / sides
    for _ in range(sides):
        t.forward(size)
        t.right(angle)
    if fill_color:
        t.end_fill()

def draw_curve(t, length, curve_factor, segments=10, fill_color=None):
    """
    Draw a curved line using small line segments
    
    Parameters:
    - t: turtle object
    - length: total length of the curve
    - curve_factor: positive for upward curve, negative for downward curve
    - segments: number of segments (higher = smoother curve)
    - fill_color: optional color to fill if creating a closed shape
    """
    if fill_color:
        t.fillcolor(fill_color)
        t.begin_fill()
        
    segment_length = length / segments
    # Save the original heading
    original_heading = t.heading()
    
    for i in range(segments):
        # Calculate the angle for this segment
        angle = curve_factor * math.sin(math.pi * i / segments)
        t.right(angle)
        t.forward(segment_length)
        t.left(angle)  # Reset the angle for the next segment
    
    # Reset to original heading
    t.setheading(original_heading)
    
    if fill_color:
        t.end_fill()
        
def jump_to(t, x, y):
    """Move turtle without drawing"""
    t.penup()
    t.goto(x, y)
    t.pendown()


# Reusable tree drawer: trunk (rectangle) + foliage (circle) (Used AI help)
def draw_tree(t, trunk_x, trunk_y,
              trunk_width=75, trunk_height=200,
              foliage_radius=95,
              trunk_color="#A86A32", foliage_color="forestgreen",
              foliage_offset_x=42, foliage_offset_y=-30):
    """
    Draw a simple tree composed of a rectangular trunk and a circular foliage.

    Parameters:
    - t: turtle object
    - trunk_x, trunk_y: starting position used for the trunk (same placement as previous code)
    - trunk_width, trunk_height: trunk dimensions
    - foliage_radius: radius of the foliage circle
    - trunk_color, foliage_color: fill colors
    - foliage_offset_x, foliage_offset_y: offset from trunk position to foliage center
    """
    # Draw trunk
    jump_to(t, trunk_x, trunk_y)
    draw_rectangle(t, trunk_width, trunk_height, fill_color=trunk_color)
    # Draw foliage (positioned relative to trunk)
    jump_to(t, trunk_x + foliage_offset_x, trunk_y + foliage_offset_y)
    draw_circle(t, foliage_radius, fill_color=foliage_color)


# Reusable house drawer: base (square) + roof (triangle) + door + window
def draw_house(t, base_x, base_y,
               size=100,
               base_color="AntiqueWhite2",
               roof_color="Brown3",
               door_width=30, door_height=50, door_color="sienna",
               window_size=30, window_color="lightblue",
               door_offset_x=30, door_offset_y=-50,
               window_offset_x=60, window_offset_y=-15):
    """
    Draw a simple house composed of a square base, a triangular roof,
    a rectangular door and a square window.

    Offsets are chosen to match the original absolute positions used in
    the script (so calling `draw_house(t, 40, 50)` reproduces the previous
    layout).
    """
    # Base (top-left at base_x, base_y)
    jump_to(t, base_x, base_y)
    draw_square(t, size, fill_color=base_color)

    # Roof (aligned with base top-left)
    jump_to(t, base_x, base_y)
    draw_triangle(t, size, fill_color=roof_color)

    # Door (positioned relative to base)
    jump_to(t, base_x + door_offset_x, base_y + door_offset_y)
    draw_rectangle(t, door_width, door_height, fill_color=door_color)

    # Window (positioned relative to base)
    jump_to(t, base_x + window_offset_x, base_y + window_offset_y)
    draw_square(t, window_size, fill_color=window_color)


# Reusable flowers drawer: petals (triangles) + center (polygon) + stem (rectangle)
def draw_flowers(t, center_x, center_y,
                 petal_count=8, petal_size=30, petal_color="HotPink",
                 center_sides=6, center_size=10, center_color="yellow",
                 stem_width=5, stem_height=20, stem_color="green",
                 center_offset_x=-5, center_offset_y=7,
                 stem_offset_x=-5, stem_offset_y=-25):
    """
    Draw a simple flower composed of triangular petals arranged in a circle,
    a polygon center, and a rectangular stem.

    Parameters:
    - t: turtle object
    - center_x, center_y: base position used for the petals (same placement as previous code)
    - petal_count: number of petals (default 8)
    - petal_size: size of each triangular petal
    - petal_color: fill color for petals
    - center_sides: sides for the center polygon
    - center_size: size for the center polygon
    - center_color: color for the center polygon
    - stem_width, stem_height: stem rectangle size
    - stem_color: color for the stem
    - center_offset_x/y, stem_offset_x/y: offsets from the petals origin to place center/stem
    """
    # Petals (drawn by rotating and drawing a triangle at the same point)
    jump_to(t, center_x, center_y)
    step = int(360 / petal_count)
    for angle in range(0, 360, step):
        t.setheading(angle)
        draw_triangle(t, petal_size, fill_color=petal_color)

    # Reset heading
    t.setheading(0)

    # Center
    jump_to(t, center_x + center_offset_x, center_y + center_offset_y)
    draw_polygon(t, center_sides, center_size, fill_color=center_color)

    # Stem
    jump_to(t, center_x + stem_offset_x, center_y + stem_offset_y)
    draw_rectangle(t, stem_width, stem_height, fill_color=stem_color)


#YOU MUST add function calls in this draw_scence function defintion
# to create your scence (No statements outside of function definiions)
def draw_scene(t):
    """Draw a colorful scene with various shapes"""
    # Set background color
    screen = t.getscreen()
    screen.bgcolor("skyblue")
    draw_rectangle(t, 800, 400, fill_color="green")  # Grass
    # Draw a tree (trunk + foliage) using the reusable function
    draw_tree(t, 200, 150)
    # Draw the house using the reusable function
    draw_house(t, 40, 50)
    # Draw several houses to create a neighborhood
    draw_house(t, 200, 25, base_color="LightYellow2", roof_color="SaddleBrown")
    draw_house(t, 350, 50, base_color="burlywood", roof_color="brown")
    jump_to(t, -300, 200)
    draw_circle(t, 40, fill_color="Khaki1")  # Sun
    jump_to(t, -350, 150)
    draw_curve(t, 100, 10, segments=20)  # Wind part 1
    jump_to(t, -200, 150)
    draw_curve(t, 100, 10, segments=20)  # Wind part 2
    jump_to(t, -300, 100)
    draw_curve(t, 100, 10, segments=20)  # Wind part 3
    jump_to(t, -200, 0)
    draw_rectangle(t, 200, 400, fill_color="Gray40")  # Road
    jump_to(t, -600, -0)
    draw_rectangle(t, 500, 400, fill_color="green")  # More grass
    # Draw several flowers with different petal colors to demonstrate the parameter
    draw_flowers(t, -350, 0, petal_color="HotPink")
    draw_flowers(t, -250, 0, petal_color="Violet")
    draw_flowers(t, -300, -5, petal_color="DarkOrchid")
    draw_flowers(t, -325, -10, petal_color="DeepPink")
    draw_flowers(t, -275, -10, petal_color="Magenta")


# This is the main() function that starts off the execution
def main():
    t, screen = setup_turtle()
    draw_scene(t)
    screen.mainloop()

# if this script is executed, call the main() function
# meaning when is file is run directly
if __name__ == "__main__":
    main()
